nList = [1, 2, 3, 4, 5, 6]
aList = ["A", "B", "C", "D", "E", "F"]
if nList == aList:
    print("nList清單的值與aList清單相同")
else:
    print("nList清單的值與aList清單不相同")