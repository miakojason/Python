lst2 = ['one', 'two', 'three', 'four', 'five', 'six']      
lst2[3] = '四'      # lst2[3]的內容由'four'更改為'四' 
print(lst2[3])      # 印出 四
print(lst2)         # 印出 ['one', 'two', 'three', '四', 'five', 'six']
