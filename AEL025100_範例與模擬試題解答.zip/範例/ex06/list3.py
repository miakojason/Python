lst3 = [23, 45, 51, 67, 89, 100]      
x = len(lst3)          # x ← 6
print(x)               # 印出 6
