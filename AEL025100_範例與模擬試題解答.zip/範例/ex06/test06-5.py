scoreList = [67, 80, 45, 50, 73]
# scoreList串列資料從學生成績資料庫取得
for index in range(len(scoreList)):
    if scoreList[index] >= 60:
        continue
    scoreList[index] = int(scoreList[index] * 1.05) + 2
        
print(scoreList)