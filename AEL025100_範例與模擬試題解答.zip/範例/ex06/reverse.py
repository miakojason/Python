animal=['dog','cat','monkey','fox','tiger']
animal.reverse()
print(animal)       # 印出 ['tiger', 'fox', 'monkey', 'cat', 'dog']
