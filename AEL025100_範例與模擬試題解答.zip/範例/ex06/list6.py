arr = [8 for x in range(6)]
for item in arr:
    print(item, end = ',')        # 印出 8,8,8,8,8,8,  
