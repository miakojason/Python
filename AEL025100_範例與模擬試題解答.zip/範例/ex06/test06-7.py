scoreList = [65, 54, 74, 48]
num, total = 0, 0
for index in range(len(scoreList)):
    num += 1
    total += scoreList[index]  
avg = total / num
print("學生成績總和為: ", total)
print("學生平均成績為: ", avg)
 
