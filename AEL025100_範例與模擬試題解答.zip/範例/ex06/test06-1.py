list1 = [1, 3]
list2 = [2, 4]
list3 = list1 + list2
list4 = list3 * 2
print(list4)


