nList = [1, 2, 3, 4, 5]
aList = ["a", "b", "c", "d", "e"]
print(nList is aList)
print(nList == aList)
nList = aList
print(nList is aList)
print(nList == aList)
