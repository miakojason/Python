lst = [y for y in range(5)]
for item in lst:
    print(item, end = ',')       # 印出 0,1,2,3,4,
