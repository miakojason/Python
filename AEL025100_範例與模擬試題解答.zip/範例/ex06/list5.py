season = ['spring','summer','autumn','winter']      
for item in season : 
    print(item, end = ' ')     # 印出 spring summer autumn winter
