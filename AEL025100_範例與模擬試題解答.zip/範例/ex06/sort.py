score = [72, 98, 86, 76, 63]          
score.sort()
print(score)               # 印出 [63, 72, 76, 86, 98]   
