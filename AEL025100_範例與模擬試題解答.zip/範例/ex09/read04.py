import os
fName = 'c:/data/stu.txt'
if os.path.isfile(fName):
    fr = open(fName, 'r')
    for lines in fr:
        print(lines.strip())
    fr.close()
else:
    print(f'{fName} 檔案路徑不存在')
