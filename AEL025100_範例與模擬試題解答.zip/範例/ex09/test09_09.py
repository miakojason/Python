f = open("database.txt", 'r')
eof = False
while eof == False:
    data = f.readline()
    if data != '':
        if data != "\n":
            print(data)
    else:
        print("結束")
        eof = True
        f.close()