def doIt(msg):
    print(msg)
    print("doIt函式")
def error():
    print("有錯誤發生")
def final():
    print("例外處理完成")

try:
    doIt()
except:
    error()
finally:
    final()