import os
pName = 'c:/data/'
if not os.path.exists(pName):
    os.mkdir(pName)
fName = open('c:/data/file01.txt', 'w')
#fName = open('c:\\data\\file01.txt', 'w')
