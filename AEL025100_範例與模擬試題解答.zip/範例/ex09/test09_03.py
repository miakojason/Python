import os
def readFile(fName):
    str1 = None
    if os.path.isfile(fName):
        fStrs = open(fName,'r')
        for str1 in fStrs:
            print (str1)

readFile('dataFile.txt')