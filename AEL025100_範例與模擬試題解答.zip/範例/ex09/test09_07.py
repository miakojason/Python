def printData(datafile):
    f = open(datafile, 'r')
    for datas in f:
        d = datas.split(",")
        print("{0:12}{1:6.1f}{2:8.2f}".format(d[0], eval(d[1]),eval(d[2])))
        
printData("products.txt")