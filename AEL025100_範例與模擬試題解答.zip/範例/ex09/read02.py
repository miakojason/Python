import os
fName = 'c:/data/stu.txt'
if os.path.isfile(fName):
    with open(fName, 'r') as fr:
        str1 = fr.readline()
        print(str1, end='')
        str2 = fr.readline(7)
        print(str2)
        print(fr.read())
else:
    print(None)