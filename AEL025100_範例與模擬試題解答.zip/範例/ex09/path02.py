import os
pName = 'c:/data/'
if os.path.exists(pName):
    print(f'{pName} 路徑為資料夾')
else:
    print(f'{pName} 資料夾路徑不存在')
    
fName = 'c:/Windows/system.ini'
if os.path.exists(fName):
    print(f'{fName} 路徑為檔案')
else:
    print(f'{fName} 檔案路徑不存在') 