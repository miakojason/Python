def div(n1, n2):
    res = n1 / n2
    print(f'{n1} / {n2} = {res}')
    
div(8, 0)
div(8, 4)