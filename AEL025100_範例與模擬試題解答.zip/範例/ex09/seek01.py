import os
fName = 'c:/data/stu.txt'
if os.path.isfile(fName):
    with open(fName, 'a+') as fa:
        fa.seek(16)
        str1 = fa.readline()
        print(str1, end='')
        fa.seek(0)
        str1 = fa.readline()
        print(str1, end='')
else:
    print(None)