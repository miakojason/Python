import os
pName = 'c:/data/'
if not os.path.exists(pName):
    os.mkdir(pName)
fw = open('c:/data/stu.txt', 'w')
fw.write('王一心, 85, 90\n')
fw.write('張三飛, 75, 87\n')
fw.write('周五瑞, 92, 71')
fw.flush()
fw.close()