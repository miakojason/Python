import os
if os.path.isfile('dataFile.txt'):
    file = open('dataFile.txt')
    print(file.read())
    file.close()
