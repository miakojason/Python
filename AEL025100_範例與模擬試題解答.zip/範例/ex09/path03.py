import os
pName = 'c:/data/'
if os.path.exists(pName):
    print(f'{pName} 路徑已存在,不必再建立')
else:
    print(f'{pName} 路徑不存在')
    os.mkdir(pName)
    print(f'{pName} 資料夾建立成功')
