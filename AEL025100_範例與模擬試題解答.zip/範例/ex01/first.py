#第一個Python程式
print('Hello Python!')
