s = 'Python 基礎必修課'
print(s[:])
print(s[7:])
print(s[:6])
print(s[5:8])
print(s[9:6:-1])
print(s[::2])
print(s[::-1])
print(s[::-2])
