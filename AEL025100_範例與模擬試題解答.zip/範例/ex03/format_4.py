print(format(123.45, '.1f'))
print(format('Python', '>8s'))
print(format('金額', '^6s') + format(12345.678, '012,.2f') + '元')
