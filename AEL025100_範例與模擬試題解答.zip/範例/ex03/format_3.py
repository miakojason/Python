s = '字串'
i = 1000
p = 0.666666
print('{:.2f}'.format(p))
print('{:,}'.format(i*i))
print('{:.2%}'.format(p))
print('{:.0f}'.format(p))
print('|{:6}|'.format(s))
print('|{:6}|'.format(i))
print('|{:>6}|'.format(s))
print('|{:<6}|'.format(i))
print('{:$^6}'.format(i))
print('{0}{{}}'.format('顯示{}'))


