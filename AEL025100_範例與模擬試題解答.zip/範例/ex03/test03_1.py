# -*- coding: utf-8 -*-
s1 = '一二AaBbCcDdEeFf三四'
print(s1[2:26])
print(s1[3:14:2])
