# -*- coding: utf-8 -*-
print('請輸入ID：')
userid = input()
print(userid)