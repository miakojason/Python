str1 = '張三'
num1 = 17
print('我是{name}今年{age}歲'.format(name = str1, age = num1))

