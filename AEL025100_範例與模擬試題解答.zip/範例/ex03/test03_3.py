# -*- coding: utf-8 -*-
score1 = score2 = score3 = 0.0
name = input('選手姓名：')
score1 = float(input('輸入第一次跳遠成績：'))
score2 = float(input('輸入第二次跳遠成績：'))
score3 = float(input('輸入第三次跳遠成績：'))
avg = (score1 + score2 + score3) / 3
print('{0:>20s},你的平均成績是:{1:5.2f}'.format (name, avg))