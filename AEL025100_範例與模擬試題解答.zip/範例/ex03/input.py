# -*- coding: utf-8 -*-
userName = input('請輸入姓名：')
age = int(input('請輸入年齡：'))
print('姓名：%s\t年齡：%d歲'%(userName,age))