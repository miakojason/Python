s1 = 'Python 基礎必修課'
print(s1[3])
print(s1[-2])
print(s1[16])
