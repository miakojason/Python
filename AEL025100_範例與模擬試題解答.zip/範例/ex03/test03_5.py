# -*- coding: utf-8 -*-
name = input('輸入學生姓名：')
score = input('輸入成績：')
print('"{0}",{1}'.format(name, score))
print("\"{0}\",{1}".format(name, score))
print('"' + name + '",' + score)
print('"{1:s}",{0:s}'.format(score,name))