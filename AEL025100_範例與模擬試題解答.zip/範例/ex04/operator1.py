k=5;
i = 'A'>'B';
j = ((5+i) == k);
k = 5+(100<50)*3+(-20!=20)*2;
print("以字串顯示：")
print('i=%s, j=%s, k=%s '%(i,j,k))
print("以整數顯示：")
print('i=%d, j=%d, k=%d '%(i,j,k))
