n = int(input("請輸入一~二位數的整數："))
if n >-10 and n <10:
    digit = "一"
elif n > -100 and n < 100:
    digit = "二"
else:
    digit = "大於二"
print("%d是%s位數"%(n, digit))

