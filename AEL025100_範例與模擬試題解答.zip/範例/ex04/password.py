pw = input('請輸入密碼：')
if (pw=="gotop168") :
    print('密碼正確，歡迎光臨')
else :
    print('密碼錯誤，拒絕進入')
 


