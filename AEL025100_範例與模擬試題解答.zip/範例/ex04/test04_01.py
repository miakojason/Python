n1 = eval(input("請輸入第一個數字："))
n2 = eval(input("請輸入第二個數字："))
if n1 < n2:
    print("第一個數字較小")
if n1 >= n2:
    print("第一個數字較大")
if n1 == n2:
     print("二個數字相等")
# if n2 = n1:
#     print("二個數字相等")

