points = 1876
grade = 5
if points > 2000 and grade >=5:
    points += 100
elif points > 1000 and grade >5:
    points += 50
else:
     points -=50
print(points)

