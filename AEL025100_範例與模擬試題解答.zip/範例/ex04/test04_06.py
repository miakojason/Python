word = input("請輸入英文單字：")
if word.lower() == word: 
    print(word, "全部小寫字母") 
elif word.upper() == word:
    print(word, "全部大寫字母")
else: 
    print(word, "有大和小寫字母")

