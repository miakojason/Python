def price(age, locate):
    money = 0
    if age >= 6 and locate == True:
        money = 100
    elif age >= 6 and locate == False:
        if age <= 17:        
            money = 200
        else:
            money = 500
    return money

print('票價=',price(5,True))
print('票價=',price(6,True))
print('票價=',price(6,False))
print('票價=',price(18,False))
print('票價=',price(18,True))
