# -*- coding: utf-8 -*-
while True:
    s = input('請輸入帳號：')
    if(s == 'gotop'):
        break
    print('帳號錯誤!')
print('帳號正確!')