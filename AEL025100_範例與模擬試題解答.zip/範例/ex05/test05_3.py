# -*- coding: utf-8 -*-
def tables():
    for x in range(2,13):
        for y in range(2,13):
            print(x, '*', y, '=',x * y, end='\t')
        print()
# main
tables()        