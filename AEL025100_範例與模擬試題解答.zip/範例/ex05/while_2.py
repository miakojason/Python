# -*- coding: utf-8 -*-
i =10
while(i > 0):
    print(i)
    i -= 1
else:
    print('時間到！')