# -*- coding: utf-8 -*-
product = 2
n = 5
while(n != 0):
    product *= n
    print(product)
    n -= 1
    if n == 3:break
