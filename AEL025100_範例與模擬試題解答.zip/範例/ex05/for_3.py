# -*- coding: utf-8 -*-
for x in 'Python': 
    print(x)
else:
    print('字串輸出完畢!')