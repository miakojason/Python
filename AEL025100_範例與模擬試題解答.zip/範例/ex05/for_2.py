# -*- coding: utf-8 -*-
sum = 0
for x in range(1,11):
    sum += x    
print (sum)
