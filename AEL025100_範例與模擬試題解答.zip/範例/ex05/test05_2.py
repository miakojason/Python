# -*- coding: utf-8 -*-
n = "12345"
while n != "-1":
    x = 0
    for c in n:
        x = x + 1
    print(x)
    n = input("請輸入數字或輸入-1結束程式：")