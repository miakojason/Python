# -*- coding: utf-8 -*-
for x in 'Python': 
    print (x)