# -*- coding: utf-8 -*-
while (1):
    x = input('請輸入身份證字號：')
    if x[-1] != '4':
        print('身份證字號正確')
        continue
    print('身份證字號不正確')
    break
    
    