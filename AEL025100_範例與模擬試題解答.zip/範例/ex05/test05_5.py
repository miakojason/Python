# -*- coding: utf-8 -*-
result_str = ""
for row in range(1, 6):
    for col in range(1, 5):
        if (row == 1 or row == 3):
            result_str = result_str + '*'
        elif col == 1:
            result_str = result_str + '*'
    result_str = result_str + '\n'
print(result_str)