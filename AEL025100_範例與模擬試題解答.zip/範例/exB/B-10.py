# 顯示 3 ~ 15 乘法表
def tables():
    for x in range(3, 16):
        for y in range(3, 16):
            print(x * y, end = '  ')
        print()
# main
tables()
