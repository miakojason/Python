import datetime
d = datetime.datetime(2021, 10, 9)
print('{:%B-%d-%y}'.format(d))