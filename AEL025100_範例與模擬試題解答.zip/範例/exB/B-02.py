classrooms = {1: '朱雀廳',  2: '玄武廰'}
classroom = input( '請輸入教室代號 : ' )
if not classroom in classrooms:
    print( '該聯誼教室不存在 ' )
else:
    print( "聯誼教室名稱為 "  + classrooms[classroom])

