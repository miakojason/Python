def power(a, b):
    return a**b
base = eval(input("請輸入底數: "))
exp = eval(input("請輸入指數: "))
res = power(base, exp)
print(f"計算結果為 {res}")