emp_number = "99"
code = ""
while emp_number != "":
    flag = False
    emp_number = input("請輸入識別碼(xx-xxxx-xxx) : ")
    code = emp_number.split('-')
    if len(code) == 3:
        if len(code[0]) == 2 and len(code[1]) == 4 and len(code[2]) == 3:
            if code[0].isdigit() and code[1].isdigit() and code[2].isdigit():
                flag = True
    print(flag)