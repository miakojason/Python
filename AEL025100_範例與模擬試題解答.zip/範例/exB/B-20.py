total = num = rate = 0
avg = 0.0
while rate != -1:
    rate = float(input("請輸入評分(1~5, -1 離開): "))
    if rate == -1:
        break
    total += rate
    num += 1
avg = float(total / num)
print("新開張旅店的滿意度評分平均為: " + format(avg, '.2f'))
    
