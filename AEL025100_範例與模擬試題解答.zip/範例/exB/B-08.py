x = 'Python1'
print(x)
y = x
x += 'Python2'
print(x)
print(y)
