def increScore(score, bonus, points = 5):
    if bonus == True:
        points = points * 3
    score = score * points
    return score
points = 8
score = 12
newScore = increScore(score, True, points)
print(newScore)
print(points)