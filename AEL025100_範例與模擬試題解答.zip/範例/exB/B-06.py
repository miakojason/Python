def divide(num1, num2):
    if num2 == 0:
        print('分母不能為零') 
    elif num1 is None or num2 is None:
        print('需要兩個數值')
    else:
        return num1 / num2
    
x=12
y=3
print(divide(x, None))