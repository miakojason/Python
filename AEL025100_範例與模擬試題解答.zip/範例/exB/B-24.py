print ("Please enter your name ? ")
name = input()
print(name)