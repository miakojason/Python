total = 100
students = 13
avg_orange = int(total/students)
print (avg_orange)
avg_orange = total//students
print (avg_orange)
