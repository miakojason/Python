idList = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
findId = 0		
while(findId < 11):
    print(idList[findId])
    if idList[findId] == 8:
        break
    else:
        findId += 1
