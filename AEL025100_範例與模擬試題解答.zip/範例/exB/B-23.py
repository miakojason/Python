item = input("輸入項目名稱: ")
sales = input("輸入銷售的數量: ")
print('"{0}", {1}'.format(item, sales))
print(f'"{item}", {sales}')
print('"' + item + '", ' + sales)

