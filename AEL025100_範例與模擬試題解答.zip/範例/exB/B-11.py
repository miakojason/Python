aList = ["q", "w", "e", "r", "t", "y"]
nList = [2, 4, 6, 8, 10, 12]
print(aList is nList)
print(aList == nList)
aList = nList
print(nList is aList)
print(nList == aList)

