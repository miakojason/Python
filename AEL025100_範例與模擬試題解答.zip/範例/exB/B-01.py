print(type(12.3))
print(type("False"))
print(type(+11E111))
print(type(True))


