def search(items, term):
    for i in range(len(items)):
        if items[i] == term:
            print("{0} 字串在串列中找到了!".format(term))
            break
        else:
            print("{0} 字串在串列中找不到!".format(term))
      
items = ["aaa","bbb","ccc","ddd","eee","fff"]
search(items,"ddd")