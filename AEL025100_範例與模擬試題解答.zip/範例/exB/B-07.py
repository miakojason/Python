 n = eval(input ("請輸入一個數值 : "))
 m = (-n)**3 
 print (m)