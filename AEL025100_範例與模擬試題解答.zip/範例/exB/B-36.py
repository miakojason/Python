score = 63
if score <= 100:
    if score >= 90:
        print('成績等級為優')
    elif score >= 80:
        print('成績等級為甲')
    elif score < 80 and score > 69:
        print('成績等級為乙') 
    else:
        print('成績不及格')
else:
    print('輸入的成績不正確') 
