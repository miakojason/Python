print(2 << 1 + 2)
print((2 << 1) + 2)
x,y=2,3
print(x >= y and x != y or x * 2 > y)
print(1 + 4 * 3 / 2 % 5)