b, i, f = True, 2, 3.4
print(b + i, b + f, i + f)
print(b - i, b - f, i - f)
print(b * i, b * f, i * f)
print(b / i, b / f, i / f)
