print(12.345)
print(1.2345e2)
print(1.2345e8)
print(1.2345e-2)