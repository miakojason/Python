c1,c2,c3=1+2j,3.4+5.6J,7.8-9j  #宣告c1、c2、c3為複數
print(c1,c2)
print(type(c3))
c4=complex(-12,6.2)  #使用內建函式complex()宣告c4為複數
print(c4)
print(c4.real, c4.imag)  #顯示複數c4的實部和虛部值