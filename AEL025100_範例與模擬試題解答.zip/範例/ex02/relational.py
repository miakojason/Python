a,b=2,3
print('a = 2, b = 3')
print('a < b = ',a < b)
print('a >= b = ',a >= b)
print('a == b', a==b)