yesNo = 'y'		#宣告yesNo變數，並指定變數值為字串'y'
#同時宣告passScore、maxScore、minScore三個變數，並指定變數值為整數60、100和0
passScore, maxScore, minScore = 60, 100, 0
power1 = power2 = 100		#宣告power1和power2變數，變數值都為100
total = 1.23456E+6	#宣告total變數，並設變數值為浮點數1234560.0
print(yesNo)
print(passScore, maxScore, minScore)
print(power1, power2)
print(total)
del total
#print(total)    #執行會產生錯誤，因為變數已經刪除