b=False         #宣告b為布林變數，變數值為False
print(type(b))  #顯示布林變數be的類別
print(type(1))  #顯示整數常值1的類別
print(bool(1))  #使用bool函式將1轉成布林值
print(bool(-1))  #使用bool函式將-1轉成布林值
print(bool('Python'))  #使用bool函式將'Python'轉成布林值