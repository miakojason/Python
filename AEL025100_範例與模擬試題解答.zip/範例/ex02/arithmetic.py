r=6.4
PI=3.14159
print("圓的半徑：",r)	
print("圓面積：",PI*r**2)  #公式：PIx半徑x半徑
print("圓周長：",PI*r*2)    #公式：PIx半徑x2	
print("球的體積：",PI*r**3*4/3)  #公式：PIx半徑x半徑x半徑x4/3