print(type("Python"))
print(type('123'))