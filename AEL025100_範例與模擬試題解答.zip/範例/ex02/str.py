print('Python') #顯示字串常值'Python'
print("3.8")    #顯示字串常值"3.8"
print("This's a book.") #字串常值中有單引號時用"..."	
print('"Hi!" says Jack.') #字串常值中有雙引號時用'...'