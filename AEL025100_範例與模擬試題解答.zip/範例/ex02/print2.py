print('Python基礎必修課')
print('%c%s先生'%('張','無忌'))
wt,price =30,20.5
print('%s%d斤,共%f元'%('香蕉',wt,wt*price))