num1 = 18
num2 = 7
num3 = 12.9
total = (num1 % num2 * 21) // 2.0 ** 3.0 - num2
print(total)

