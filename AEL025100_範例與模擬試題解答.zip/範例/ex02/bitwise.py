print(5 & 3)
print(5 | 3)
print(5 ^ 3) 
print(~5)