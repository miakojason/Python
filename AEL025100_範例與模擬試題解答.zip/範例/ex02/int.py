print(12)     #以十進制顯示 
print(0b1100) #以二進制顯示 
print(0o14)   #以八進制顯示
print(0xc)    #以十六進制顯示