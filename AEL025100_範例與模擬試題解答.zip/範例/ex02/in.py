print('P' in 'Python')     #'P'是否包含在'Python'中
print('x' not in 'Python') #'x'是否不包含在'Python'中
print(1 in [1,2,3])        #1是否包含在[1,2,3]陣列中
print(2 not in [1,2,3])    #2是否不包含在[1,2,3]陣列中