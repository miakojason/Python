print('Python',3.8)
print('台北','台中','台南',sep=',')
print('高雄','屏東',sep='\t')
print('價目表：',end='')
money=30
print('陽春麵',money,'元')
print(12)