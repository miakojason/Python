print(20>>1)
print(20<<1)