s1 = '字串1'
print(s1)
s2 = s1
s1 += '字串2'
print(s1)
print(s2)

