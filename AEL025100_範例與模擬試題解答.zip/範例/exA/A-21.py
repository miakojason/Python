# -*- coding: utf-8 -*-
def read_data(fileName):
    line=None
    if os.path.isfile(fileName):
        f=open(fileName,'r')
        for line in f:
            print(line)
