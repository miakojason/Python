# -*- coding: utf-8 -*-
def func1(x=30, y=20, z=0, a=0, b=0):
    t = 0
    if z > 0:
        return  z * a
    if b > 0:
        pass
    if x > 30:
        t = (x-30) * (1.2 * y)
        return t + (30 * y)
    else:
        return x * y
