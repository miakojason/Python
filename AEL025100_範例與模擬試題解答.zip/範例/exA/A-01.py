# -*- coding: utf-8 -*-
year = input("請輸入西元年： ")
roc = eval(year) - 1911
msg = f"中華民國{roc}年"
print (msg)
