# -*- coding: utf-8 -*-
words = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
print (words[3:14])
print (words[3:14:3])
print (words[15:2:-3])
print (words[::-3])
