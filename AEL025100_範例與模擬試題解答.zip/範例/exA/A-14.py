# -*- coding: utf-8 -*-
total=num=stop=0
average=0.0
while stop!=-1:
    score = float(input("請輸入1-10的評分(-1離開)"))
    if score == -1:
        break
    total += score
    num += 1
average = float(total/num)
print("平均給分為：",format(average,'.2f'))
