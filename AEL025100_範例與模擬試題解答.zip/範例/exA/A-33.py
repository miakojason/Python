# -*- coding: utf-8 -*-
itemName = input('請輸入產品名稱：')
price = input('請輸入售價：')
print('"{0}",{1}'.format(itemName,price))
print('"'+itemName +'",'+price)