# -*- coding: utf-8 -*-
a = "薯條"
b = "熱咖啡"
c = "雞腿堡"
s = " {1} 加 {0} 加 {2}"
print(s.format(a, b, c))
