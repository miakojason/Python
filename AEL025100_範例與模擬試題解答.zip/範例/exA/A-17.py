# -*- coding: utf-8 -*-
import os
file = open('daily.txt', 'a')
file.write("檔案結尾")
file.close()
