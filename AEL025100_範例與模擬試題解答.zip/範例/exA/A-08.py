# -*- coding: utf-8 -*-
import datetime

date=datetime.datetime(2021,12,25)
print('{:%B-%d-%y}'.format(date))
