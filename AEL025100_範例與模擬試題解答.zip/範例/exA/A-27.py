# -*- coding: utf-8 -*-
n=int(input("請輸入1到2位數的整數："))
nLen="零"
if n>=-9 and n <=9:
    nLen="一"
elif n>=-99 and n <=99:
    nLen="二"
else:
    nLen="大於二"
print(n," 是" + nLen + "位數")
