# -*- coding: utf-8 -*-
def func1(x, y):
    return x / y
a = input('請輸入第一個數字： ')
b = input('請輸入第二個數字： ')
result = func1(a, b)
print('兩數相除等於', result)
