# -*- coding: utf-8 -*-
def count_word(letter, wordList):
    c1 = 0
    for word in wordList:
        if letter is word:
            c1 += 1
    return c1
wordList = 'Hello'
letter = input('請輸入要查詢的字母：')
letterCount = count_word(letter, wordList)
print(letter+"字母總共使用：" , letterCount ,"次")
