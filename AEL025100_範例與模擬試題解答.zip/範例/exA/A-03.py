# -*- coding: utf-8 -*-
v1 = 35
v2 = 8
v3 = 3.0
ans = (v1 % v2 * 100) // 2.0 ** v3 - v2
print (ans)
