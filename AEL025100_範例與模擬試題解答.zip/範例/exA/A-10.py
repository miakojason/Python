# -*- coding: utf-8 -*-
def getName():
    name=input('請輸入姓名：')
    return name
def getCal(km, rate):
    cals=km*rate
    return cals
kms=int(input('請輸入慢跑的公里數：'))
calRate=68
userName=getName()
userCal=getCal(kms,calRate)
print(userName,'你消耗',userCal,'大卡')