# -*- coding: utf-8 -*-
points = 76
grade = 3
if points > 80 and grade >= 3:
      points += 10
elif points >= 70 and grade > 3:
      points += 5
else:
      points -=5
print(points)
