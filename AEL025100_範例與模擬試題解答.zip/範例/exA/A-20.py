# -*- coding: utf-8 -*-
# 目的：描述函式的功用
# 輸入：說明引數的用途
# 傳回：說明函式傳回值
def area(w, h):
    print ('# 計算方形面積 #')
    return w * h # 傳回值
