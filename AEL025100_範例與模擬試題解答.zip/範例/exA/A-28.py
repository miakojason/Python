# -*- coding: utf-8 -*-
num = 2
while num <= 50:
    isPrime = True
    for i in range(2, num):
        if num % i == 0:
            isPrime = False
            continue
    if isPrime == True:
        print(num)
    num = num + 1