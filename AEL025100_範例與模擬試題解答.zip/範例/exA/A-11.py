# -*- coding: utf-8 -*-
def add_score(score, rest, add):
    if rest==False:
        add=add*2
    score=score+add
    return score
add=5
score=80
newScore=add_score(score,False,add)
