# -*- coding: utf-8 -*-
import sys
try:
    name1 = 'esc.py'
    file1 = open(name1, 'r')
    file2 = open('list.txt', 'w+')
except IOError:
    print(name1 + '檔案讀取失敗')
else:
    file2.write(name1 + '檔案讀取成功\n')
    file1.close()
    file2.flush()
    file2.close()
