# -*- coding: utf-8 -*-
num = 4
n = 6
while(n != 0):
    num *= n
    print(num)
    n -= 1
    if n == 4:break
