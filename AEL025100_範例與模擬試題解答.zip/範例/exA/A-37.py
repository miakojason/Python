# -*- coding: utf-8 -*-
list1 = [1,2,3,4,5,6]
list2 = ['A','B','C','D','E', 'F']
if list1 == list2:
    print('串列相等')
else:
    print('串列不相等')
