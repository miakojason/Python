# -*- coding: utf-8 -*-
x = '0'
while x != '-1':
    c1 = 0
    for char in x:
        c1 += 1
    print(c1)
    x = input('請輸入任意長度數字或「-1」結束程式：')