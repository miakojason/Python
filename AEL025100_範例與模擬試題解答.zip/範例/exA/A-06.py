# -*- coding: utf-8 -*-
n1 = int(input('請輸入第1個整數：'))
n2 = int(input('請輸入第2個整數：'))
if n1 == n2:
    print('第1個整數等於第2個整數')
if n1 <= n2:
    print('第1個整數小於等於第2個整數')
if n1 > n2:
    print('第1個整數大於第2個整數')
if n1 = n2:
    print('第1個整數等於第2個整數')
