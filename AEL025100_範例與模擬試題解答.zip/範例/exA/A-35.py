# -*- coding: utf-8 -*-
for s in  range (len(scoreList) ) :
    if scoreList[s] >= 50:
        continue
    scoreList[s] = (scoreList[s] * 1.03)+2
    
