# -*- coding: utf-8 -*-
import os
if os.path.isfile('daily.txt'):
    file = open('daily.txt')
    print(file.read())
    file.close()
