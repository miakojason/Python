# -*- coding: utf-8 -*-
from random import randint
ans=randint(1,9)
n=1
print('猜測1到9的整數，最多4次')
while n <= 4:
    guess=int(input('請輸入1到9的整數：'))
    if ans > guess:
        print('猜的數太小')
    elif ans < guess:
        print('猜的數太大')
    else:
        print('猜對了')
        break
    n += 1