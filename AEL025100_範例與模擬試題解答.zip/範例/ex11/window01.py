import tkinter as tk

win = tk.Tk()
win.title('第一個視窗應用程式')
win.geometry('400x200')
win.mainloop()