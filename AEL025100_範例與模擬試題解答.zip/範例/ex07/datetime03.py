import datetime as DT
nowTime = DT.datetime.now()
print('{:%Y/%b/%d  %A}'.format(nowTime)) 
print(f'{nowTime:%Y/%b/%d  %A}')
print(nowTime.strftime("%Y/%b/%d  %A"))