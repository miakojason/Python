import time as T
num = T.time()
print(num)
