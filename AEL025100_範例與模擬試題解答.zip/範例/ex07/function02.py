def average(n1, n2):
    a = (n1 + n2) / 2
    return a 

print('輸入第 1 個整數：' , end='')
num1 = eval(input())
num2 = eval(input('輸入第 2 個整數：'))
avg = average(num1, num2)
print(f'{num1} 和 {num2} 兩整數平均為：{avg:.1f}', end = '')
