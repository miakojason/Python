import time as T          # 匯入 time 套件名稱,另取別名為 T 
st = T.ctime()
print(st) 
