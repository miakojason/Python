def input_name():
     name = input("請輸入姓名：")
     return name
def calc(num, calCup):
     total_cal = num * calories
     return total_cal
cups = int(input("請輸入一天喝幾杯珍珠奶茶？")) 
calCup = 160
user = input_name()
calories = calc(cups, calCup)
print(user + " 你攝取了", calories, "大卡")
