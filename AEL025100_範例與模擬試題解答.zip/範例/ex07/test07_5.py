def add_score(score, rest, add):
     if rest == False:
          add *= 2
     score = score + add
     return score
stuScore = 75
add = 2
newScore = add_score(stuScore, True, add)

print(newScore)