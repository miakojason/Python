import datetime
dd = datetime.datetime(2021, 11, 7)
print('{:%B-%d-%y}'.format(dd))
