from random import randint
print(randint(1, 20)*3)
from random import randrange
print(randrange(3,63,3))

