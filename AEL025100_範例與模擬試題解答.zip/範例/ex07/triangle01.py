def triangle(B, H):
    A = B * H / 2
    return A

base = 10
area = triangle(base)
print(area)
