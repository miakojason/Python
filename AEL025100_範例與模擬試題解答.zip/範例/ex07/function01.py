def average(n1, n2):
    a = (n1 + n2) / 2
    return a
