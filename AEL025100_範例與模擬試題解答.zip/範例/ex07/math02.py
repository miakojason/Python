from math import *
num = sqrt(49)

print(num)