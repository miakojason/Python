import datetime as DT
setTime = DT.datetime(1969,7,20)
print(setTime)
