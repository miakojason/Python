import random as R

for i in range(5):
    rnd = R.randint(1, 10)
    print(f'第 {i+1} 個亂數 : {rnd}')
