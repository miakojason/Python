data = "水泥股,9.45,10350"
ary = data.split(",")
s1 = "{:>8}{:7.2f}{:8,}"
print(s1.format(ary[0],eval(ary[1]),eval(ary[2])))
data = "食品股,50.5,2235"
ary = data.split(",")
print(s1.format(ary[0],eval(ary[1]),eval(ary[2])))
